"""duck_walker controller."""

from controller import Robot
import math

def run_robot(robot):
    # 取得基本時間步長
    timestep = int(robot.getBasicTimeStep())
    
    # --- 1. 初始化馬達 ---
    # 根據您的 .wbt 檔案中的命名定義馬達名稱
    motor_names = [
        "Head_Yaw", "Head_Pitch",
        "L_Hip_Yaw", "L_Hip_Roll", "L_Hip_Pitch", "L_Knee", "L_Ankle",
        "R_Hip_Yaw", "R_Hip_Roll", "R_Hip_Pitch", "R_Knee", "R_Ankle"
    ]
    
    motors = {}
    for name in motor_names:
        motor = robot.getDevice(name)
        if motor:
            motor.setPosition(0)  # 初始化位置歸零
            motor.setVelocity(5.0)  # 設定馬達速度
            motors[name] = motor
            print(f"Initialized {name}")
        else:
            print(f"Warning: Motor {name} not found!")

    # --- 2. 行走參數設定 (可在此調整步伐大小與速度) ---
    FREQUENCY = 1.4      # 頻率 (步伐速度)
    WALK_AMPLITUDE = 0.4 # 前後跨步幅度 (Pitch)
    ROLL_AMPLITUDE = 0.15 # 左右搖擺幅度 (Roll) - 鴨子走路的關鍵
    KNEE_BENDING = 0.3   # 膝蓋彎曲程度 (抬腿高度)
    
    # 初始姿勢微調 (Offset)
    hip_pitch_offset = -0.2  # 身體微前傾以保持平衡
    knee_offset = 0.4        # 膝蓋保持微彎
    ankle_offset = -0.2      # 腳踝修正
    
    t = 0.0

    # --- 3. 主迴圈 ---
    while robot.step(timestep) != -1:
        t += timestep / 1000.0  # 更新時間 (秒)
        
        # 計算相位 (左右腳差 180 度，即 pi)
        phase_l = t * 2 * math.pi * FREQUENCY
        phase_r = phase_l + math.pi
        
        # --- 計算目標角度 (正弦波步態) ---
        
        # 1. 髖部前後擺動 (Hip Pitch) - 帶動大腿前後
        l_hip_pitch_target = WALK_AMPLITUDE * math.sin(phase_l) + hip_pitch_offset
        r_hip_pitch_target = WALK_AMPLITUDE * math.sin(phase_r) + hip_pitch_offset
        
        # 2. 髖部左右搖擺 (Hip Roll) - 重心轉移
        # 左右腳 Roll 通常同相或微差，讓身體整體向左/向右倒
        l_hip_roll_target = ROLL_AMPLITUDE * math.sin(phase_l)
        r_hip_roll_target = ROLL_AMPLITUDE * math.sin(phase_l) # 同向搖擺
        
        # 3. 膝蓋彎曲 (Knee) - 抬腿
        # 膝蓋只在往前跨步時彎曲，使用 abs 或 sin 的特定區段，這裡用簡單的 sin 配合 offset
        l_knee_target = KNEE_BENDING * max(0, math.sin(phase_l)) + knee_offset
        r_knee_target = KNEE_BENDING * max(0, math.sin(phase_r)) + knee_offset
        
        # 4. 腳踝補償 (Ankle) - 保持腳掌水平
        # 腳踝動作通常與髖部+膝蓋相反，以抵消旋轉讓腳底貼地
        l_ankle_target = -l_hip_pitch_target - l_knee_target + ankle_offset
        r_ankle_target = -r_hip_pitch_target - r_knee_target + ankle_offset

        # --- 寫入馬達 ---
        # 左腳
        motors["L_Hip_Pitch"].setPosition(l_hip_pitch_target)
        motors["L_Hip_Roll"].setPosition(l_hip_roll_target)
        motors["L_Knee"].setPosition(l_knee_target)
        motors["L_Ankle"].setPosition(l_ankle_target)
        
        # 右腳
        motors["R_Hip_Pitch"].setPosition(r_hip_pitch_target)
        motors["R_Hip_Roll"].setPosition(r_hip_roll_target)
        motors["R_Knee"].setPosition(r_knee_target)
        motors["R_Ankle"].setPosition(r_ankle_target)
        
        # 頭部與其他關節保持穩定或微動
        motors["Head_Yaw"].setPosition(0.1 * math.sin(t)) # 頭部微微轉動看起來更自然
        motors["L_Hip_Yaw"].setPosition(0)
        motors["R_Hip_Yaw"].setPosition(0)

if __name__ == "__main__":
    robot = Robot()
    run_robot(robot)