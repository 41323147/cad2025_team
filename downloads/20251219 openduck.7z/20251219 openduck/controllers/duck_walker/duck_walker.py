from controller import Robot
import math

class DuckWalker:
    def __init__(self):
        # 1. 初始化 Webots 機器人
        self.robot = Robot()
        self.timestep = int(self.robot.getBasicTimeStep())
        
        # 2. 定義馬達 (對應您的 bot4.wbt 名稱)
        self.motor_names = [
            'Head_Yaw', 'Head_Pitch',
            'L_Hip_Yaw', 'L_Hip_Roll', 'L_Hip_Pitch', 'L_Knee', 'L_Ankle',
            'R_Hip_Yaw', 'R_Hip_Roll', 'R_Hip_Pitch', 'R_Knee', 'R_Ankle'
        ]
        
        self.motors = {}
        
        print(">>> 鴨子走路控制器初始化...")
        print(">>> 請確認 .wbt 檔中的腳掌尺寸已修正為 0.1 左右，否則無法移動！")

        for name in self.motor_names:
            motor = self.robot.getDevice(name)
            if motor:
                motor.setPosition(0.0)
                # 設定馬達出力速度 (數值越大越有力，但不是走路速度)
                motor.setVelocity(5.0) 
                self.motors[name] = motor

    def set_joint(self, name, pos):
        """ 安全設定關節角度 """
        if name in self.motors:
            # 限制角度範圍，防止穿模
            pos = max(min(pos, 1.5), -1.5)
            self.motors[name].setPosition(pos)

    def run(self):
        # --- [參數調整區] ---
        # 走路速度 (數值越小越慢)
        WALK_FREQ = 3.0       
        
        # 基礎蹲姿 (膝蓋前驅的核心，數值越大蹲越低，重心越穩)
        BASE_KNEE = 0.40      
        
        # 動作幅度
        LIFT_HEIGHT = 0.20    # 抬腳高度 (太低會磨地，太高會不穩)
        STRIDE_LEN  = 0.35    # 跨步大小 (前進的主要動力)
        SWAY_AMT    = 0.10    # 左右搖擺 (幫助重心轉移)
        
        # 身體前傾 (幫助前進)
        BODY_LEAN   = 0.10    

        # 直線微調 (如果走歪了，調整這個值)
        # 正值往左修，負值往右修
        TRIM = 0.0

        print(">>> 開始行走 Loop")
        
        while self.robot.step(self.timestep) != -1:
            # 獲取時間 t
            t = self.robot.getTime()
            
            # 產生基礎波形
            # sin_t 控制左右搖擺
            # cos_t 控制前後跨步 (相位差 90 度)
            sin_t = math.sin(t * WALK_FREQ)
            cos_t = math.cos(t * WALK_FREQ)
            
            # 1. 左右重心轉移 (Hip Roll)
            # 當 sin_t 為正，身體往左擺，準備抬右腳
            roll = (sin_t * SWAY_AMT) + TRIM
            
            # 2. 前後跨步 (Hip Pitch)
            # 左腳與右腳相位相反
            l_pitch = (cos_t * STRIDE_LEN) - BODY_LEAN
            r_pitch = (-cos_t * STRIDE_LEN) - BODY_LEAN
            
            # 3. 膝蓋抬起 (Knee Lift)
            # 我們希望當身體往左歪(sin_t > 0)時，抬起右腳
            # 當身體往右歪(sin_t < 0)時，抬起左腳
            
            l_knee_lift = 0
            r_knee_lift = 0
            
            if sin_t < 0: 
                # 身體往右，抬左腳
                # 使用 sin_t 的負值部分來產生抬起動作
                l_knee_lift = -sin_t * LIFT_HEIGHT
            else:
                # 身體往左，抬右腳
                r_knee_lift = sin_t * LIFT_HEIGHT

            # 總膝蓋角度 = 基礎蹲姿 + 抬腳動作
            l_knee = BASE_KNEE + l_knee_lift
            r_knee = BASE_KNEE + r_knee_lift
            
            # 4. 腳踝補償 (Ankle Lock) - 關鍵！
            # 讓腳底板永遠保持水平的公式： Ankle = -(Hip + Knee)
            # 這樣無論膝蓋怎麼動，腳底都會是平的
            l_ankle = -(l_pitch + l_knee)
            r_ankle = -(r_pitch + r_knee)
            
            # --- 執行指令 ---
            self.set_joint('L_Hip_Roll', roll)
            self.set_joint('R_Hip_Roll', roll)
            
            self.set_joint('L_Hip_Pitch', l_pitch)
            self.set_joint('R_Hip_Pitch', r_pitch)
            
            self.set_joint('L_Knee', l_knee)
            self.set_joint('R_Knee', r_knee)
            
            self.set_joint('L_Ankle', l_ankle)
            self.set_joint('R_Ankle', r_ankle)

if __name__ == "__main__":
    controller = DuckWalker()
    controller.run()